Jogo para a materia de metodos numericos 2015-1
Autor - Tiago R. Assuncao 13 0051187

Instrucoes
O jogo  deve ser iniciado no arquivo mainJogoBissecao.m
Na tela de dados, deve ser inserido uma equacao y em funcao de x. Ex.:  (x*x*)-20
Os demais campos devem ser preenchidos com numeros inteiros ou de ponto flutuante.
